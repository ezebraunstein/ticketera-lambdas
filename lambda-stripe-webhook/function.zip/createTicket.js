const AWS = require('aws-sdk');
const Swal = require('sweetalert2');
const { v4: uuid } = require('uuid');
const QRGenerator = require('./qrGenerator');


const dynamoDb = new AWS.DynamoDB.DocumentClient();

const handleCheckout = async (data, cart, eventData) => {

    const emailUser = data.email;
    const dniUser = data.dni;

    try {
        const ticketPromises = cart.flatMap(async (item) => {
            return Array.from({ length: item.selectedQuantity }, async () => {
                const ticketId = uuid();
                const nameEvent = eventData.nameEvent;
                const eventId = eventData.id;
                const nameTT = item.nameTT;
                const key = await QRGenerator(eventId, ticketId, emailUser, nameEvent, nameTT);
                const ticketData = {
                    id: ticketId,
                    qrTicket: key,
                    validTicket: true,
                    dniTicket: dniUser,
                    emailTicket: emailUser,
                    typeticketID: item.id,
                };
                await dynamoDb.put({
                    TableName: 'Ticket-zn4tkt5eivea5af5egpjlychcm-dev',
                    Item: ticketData
                }).promise();
            });
        });

        await Promise.all(ticketPromises);

        Swal.fire({
            icon: 'success',
            title: 'Ticket(s) enviados correctamente! Revisa tu casilla de spam!',
            showConfirmButton: true,
            confirmButtonText: 'Aceptar'
        });

    } catch (error) {
        Swal.fire({
            icon: 'error',
            title: 'Error creating ticket(s)',
        });
    }
};

module.exports = handleCheckout;
