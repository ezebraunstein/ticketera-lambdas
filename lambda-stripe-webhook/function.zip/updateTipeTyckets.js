const AWS = require('aws-sdk');

const dynamoDB = new AWS.DynamoDB.DocumentClient();

const updateTypeTicket = async (cart) => {

    for (const item of cart) {

        const itemID = item.id;
        const itemQuantity = item.quantityTT + item.selectedQuantity;

        await dynamoDB.update({
            TableName: 'TypeTicket-zn4tkt5eivea5af5egpjlychcm-dev',
            Key: { id: itemID },
            UpdateExpression: 'set quantityTT = :q',
            ExpressionAttributeValues: { ':q': itemQuantity },
        }).promise();
    }

};

module.exports = updateTypeTicket;
